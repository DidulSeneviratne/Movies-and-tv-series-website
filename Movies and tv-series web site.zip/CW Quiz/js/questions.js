let MCQS = [{
    question: "Steven SpielbergWho is the Director of the movie “Titanic”?",
    choice1: "Christopher Nolan",
    choice2: "James Cameron",
    choice3: "Quentin Tarantino",
    choice4: "Steven Spielberg",
    answer: 1
},
    {
    question: "When was the first Spiderman movie by Tobey Maguire released?",
    choice1: "2003",
    choice2: "2001",
    choice3: "2002",
    choice4: "2005",
    answer: 2
},
    {
    question: "Which was the first full-length animated feature film made by Walt Disney Animation Studios?",
    choice1: "The Three Caballeros",
    choice2: "Snow White and the Seven Dwarfs",
    choice3: "Dumbo",
    choice4: "The Adventures of Ichabod and Mr. Toad",
    answer: 1
},
    {
    question: "When was “Finding Nemo” released?",
    choice1: "2007",
    choice2: "1999",
    choice3: "2003",
    choice4: "2005",
    answer: 2
},
    {
    question: "Who is Thomas Shelby in the TV series “Peaky Blinders”?",
    choice1: "Paul Anderson",
    choice2: "Cillian Murphy",
    choice3: "Tom Hardy",
    choice4: "Finn Cole",
    answer: 1
},
    {
    question: "When was the first Fast & Furious released?",
    choice1: "2005",
    choice2: "2003",
    choice3: "2001",
    choice4: "2007",
    answer: 2
},
    {
    question: "Your Who created “The Simpsons”",
    choice1: "Matt Groening",
    choice2: "Alf Clausen",
    choice3: "Richard Gibbs",
    choice4: "Sam Simon",
    answer: 0
},{
    question: "Who acted as Sherlock Holmes in Sherlock TV-Series?",
    choice1: "Martin Freeman",
    choice2: "Andrew Scott",
    choice3: "Mark Gatiss",
    choice4: "Benedict Cumberbatch",
    answer: 3
},
    {
    question: "Who is the cast of Sheldon Cooper in the TV-Series Young Sheldon?",
    choice1: "Jim Parsons",
    choice2: "Iain Armitage",
    choice3: "Lance Barber",
    choice4: "Montana Jordan",
    answer: 1
},
    {
    question: "Name the cast of Black Panther?",
    choice1: "Andy Serkis",
    choice2: "John Kani",
    choice3: "Michael Jordan",
    choice4: "Chadwick Boseman",
    answer: 3
}];